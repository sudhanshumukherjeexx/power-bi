Northwind Starter - Power BI Holy Grail
=======================================

1. Unzip so this folder is C:\PowerBI\northwind-starter\ (the CSVs are in its data\ subfolder).
2. Open "Northwind Starter.pbip" in Power BI Desktop and click Refresh.

Unzipped somewhere else? Transform data > Edit parameters > DataFolder, then paste the full path
to the data folder, ending with a backslash. You can also paste the website address of the data
folder (https://<you>.github.io/<repo>/data/) so the model refreshes from the web.

What is inside: 12 tables, 11 relationships (FactSales.ShipDate -> DimDate is inactive, for
USERELATIONSHIP), DimDate marked as the date table, auto date/time off, no measures.
RawOrdersExport and SurveyWide are not included: cleaning them is part of the Power Query topics.
